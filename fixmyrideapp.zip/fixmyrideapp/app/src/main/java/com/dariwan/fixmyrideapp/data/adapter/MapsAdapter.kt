package com.dariwan.fixmyrideapp.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dariwan.fixmyrideapp.data.response.NearbyItem

//class MapsAdapter: RecyclerView.Adapter<MapsAdapter.MapsAdapterViewHolder>() {
//
//    private val list: MutableList<NearbyItem> = mutableListOf()
//
//    class MapsAdapterViewHolder {
//
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MapsAdapterViewHolder {
//        val inflater = LayoutInflater.from(parent.context)
//    }
//
//    override fun onBindViewHolder(holder: MapsAdapterViewHolder, position: Int) {
//        TODO("Not yet implemented")
//    }
//
//    override fun getItemCount(): Int {
//        return resultList.size
//    }
//}