package com.dariwan.fixmyrideapp.data.api

import com.dariwan.fixmyrideapp.data.response.PredictionRequest
import com.dariwan.fixmyrideapp.data.response.PredictionResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiServiceML {
    @POST("/predict")
    suspend fun predict(@Body request: PredictionRequest): PredictionResponse
}