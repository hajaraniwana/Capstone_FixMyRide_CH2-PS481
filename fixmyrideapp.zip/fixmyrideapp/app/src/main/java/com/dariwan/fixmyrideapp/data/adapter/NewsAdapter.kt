package com.dariwan.fixmyrideapp.data.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dariwan.fixmyrideapp.data.response.NewsData
import com.dariwan.fixmyrideapp.databinding.ItemNewsBinding
import com.dariwan.fixmyrideapp.view.detailnews.DetailActivity
import com.dariwan.fixmyrideapp.view.detailnews.DetailActivity.Companion.LINK_URL

class NewsAdapter : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    private val news: MutableList<NewsData> = mutableListOf()

    class NewsViewHolder(val binding: ItemNewsBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(news: NewsData) {
            binding.tvTittleNews.text = news.title
            binding.tvDescNews.text = news.description
            binding.tvTypeNews.text = news.type
            Glide.with(itemView.context)
                .load(news.photo_url)
                .into(binding.imgNews)
        }

    }

    override fun onBindViewHolder(holder: NewsAdapter.NewsViewHolder, position: Int) {
        val news = news[position]
        holder.bind(news)

        holder.binding.root.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailActivity::class.java)
            intent.putExtra(DetailActivity.LINK_URL, news.link_url)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsAdapter.NewsViewHolder {
        val binding = ItemNewsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NewsViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return news.size
    }

    fun submitList(newNews: List<NewsData>) {
        news.clear()
        news.addAll(newNews)
        notifyDataSetChanged()
    }

}